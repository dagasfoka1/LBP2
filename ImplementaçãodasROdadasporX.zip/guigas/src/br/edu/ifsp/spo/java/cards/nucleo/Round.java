package br.edu.ifsp.spo.java.cards.nucleo;

public class Round {
}
