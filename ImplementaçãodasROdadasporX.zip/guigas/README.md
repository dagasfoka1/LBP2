# PROJETO CARDS

Este projeto está sendo utilizado para exercitar conceitos básicos de aplicações JAVA.

Até o momento as seguintes classes e enums estão presentes:

- Card (Carta): Representa uma carta de baralho
- Deck (Baralho): Representa um conjunto de cartas, ou seja, um baralho
- Suit (Naipe): Enum com os naipes possíveis
- Rank (Valor): Enum representando os valores possíveis de uma carta.  