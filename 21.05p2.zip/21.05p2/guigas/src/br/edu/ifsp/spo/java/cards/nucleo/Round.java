package br.edu.ifsp.spo.java.cards.nucleo;

public class Round {
    private int Rodadas;
    int getRodadas(){
        return this.Rodadas;
    }
    public void addRodadas(int num){
        this.Rodadas=num;
    }
}
