package br.edu.ifsp.spo.java.cards.regras;

import br.edu.ifsp.spo.java.cards.nucleo.Jogador;
import br.edu.ifsp.spo.java.cards.ui.JogoUI;

import java.util.Optional;

public class Vencedor {
    public Boolean verificarEstouro(Jogador jogador, Pontuador pontuador){
        var pontuacaoJogador = pontuador.verificarPontuacao(jogador.getMao());
        return pontuacaoJogador > 21;
    }
    public Boolean verificar21(int pontuacao){
        return pontuacao==21;
    }

    public Optional<Jogador> verificarVencedor(Pontuador pontuador, Jogador jogador1, Jogador jogador2) {
        var pontuacaoJogador1 = pontuador.verificarPontuacao(jogador1.getMao());
        var pontuacaoJogador2 = pontuador.verificarPontuacao(jogador2.getMao());

        var empate = (pontuacaoJogador1 > 21 && pontuacaoJogador2 > 21) || (pontuacaoJogador1 == pontuacaoJogador2);

        Optional<Jogador> vencedor = Optional.empty();

        if(!empate){
            if(pontuacaoJogador1 > 21)
                vencedor = Optional.of(jogador2);
                
            else if(pontuacaoJogador2 > 21)
                vencedor = Optional.of(jogador1);
            else
                vencedor = Optional.of(pontuacaoJogador1>pontuacaoJogador2? jogador1 : jogador2);
        }

        return vencedor;
    }
}
